# How to Test "Focus Manager" Locally

Before publishing, you should verify that the extension works correctly on your own machine.

## 1. Load the Extension into Chrome

1.  Open Google Chrome.
2.  In the address bar, type `chrome://extensions` and press Enter.
3.  In the top-right corner, toggle the **Developer mode** switch to **ON**.
4.  Click the **Load unpacked** button that appears in the top-left.
5.  Navigate to and select the `focus-manager` folder in your project directory:
    *   `/Users/rwaida/.gemini/antigravity/playground/perihelion-filament/focus-manager`

## 2. Verify Installation

1.  You should see "Focus Manager - Calendar Aware Blocker" appear in your list of extensions.
2.  Look for the extension icon (a puzzle piece or the default icon) in your Chrome toolbar.
3.  Click the **Puzzle Piece** icon and **Pin** Focus Manager so it's always visible.

## 3. Test Functionality (Simulation Mode)

By default, the extension is in **Simulation Mode**. This is great for testing the UI and blocking logic without needing a real Google Calendar connection.

1.  **Open the Popup**: Click the Focus Manager icon.
2.  **Check Initial State**: It should say "Idle" and "No active meeting".
3.  **Activate Sync**: Click the **Sync Calendar** button.
    *   *What happens*: The extension simulates finding a "Deep Work Session" that started 5 minutes ago.
4.  **Verify Focus Mode**:
    *   The badge should change to **Focus Mode** (Green).
    *   The circle should pulse.
    *   The current event should show "Deep Work Session".
5.  **Test Blocking**:
    *   Open a new tab and go to `https://www.facebook.com` or `https://www.twitter.com`.
    *   **Result**: The page should be blocked (Chrome will show a "This site is blocked" or connection error page depending on the exact blocking method, usually `ERR_BLOCKED_BY_CLIENT`).
6.  **Check Stats**:
    *   Re-open the popup.
    *   The "Distractions Blocked" count should have increased (simulated).

## 4. Debugging

If something isn't working:

1.  Go back to `chrome://extensions`.
2.  Find Focus Manager.
3.  Click **Service Worker** (blue link).
4.  This opens the **DevTools** for the background script.
5.  Look at the **Console** tab for any red errors or logs (e.g., "Focus Manager Installed").

## 5. Testing Real Calendar Integration (Advanced)

Once you are happy with the UI and blocking:

1.  Follow the **Publishing Guide** to get a real Client ID.
2.  Update `manifest.json` and `background.js`.
3.  Go to `chrome://extensions` and click the **Refresh** (circular arrow) icon on the Focus Manager card.
4.  Open the popup and click **Sync**.
5.  It should now prompt you to **Sign In with Google**.
6.  Create a test event in your actual Google Calendar for the current time.
7.  Verify that the extension detects it and blocks sites.

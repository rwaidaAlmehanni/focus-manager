# How to Publish "Focus Manager" to the Chrome Web Store

Publishing your extension allows anyone to install it from the Chrome Web Store. Here is the step-by-step process.

## 1. Prepare Your Extension for Production

Before uploading, you must ensure the extension is ready for real users.

### A. Switch to Real Calendar Mode
1.  **Get a Real OAuth Client ID**:
    *   Go to the [Google Cloud Console](https://console.cloud.google.com/).
    *   Create a project and enable the **Google Calendar API**.
    *   Configure the **OAuth Consent Screen** (you will need to submit this for verification if you want it public).
    *   Create credentials for a **Chrome Extension**. You will need the extension's **Item ID** (see Step 3 below) to finish this.
2.  **Update Code**:
    *   In `background.js`, change `const SIMULATION_MODE = true;` to `false`.
    *   In `manifest.json`, replace `"YOUR_CLIENT_ID_HERE"` with your actual Client ID.

### B. Create Required Assets
You need specific images for the store listing:
*   **Icon**: A 128x128px PNG file (you already have a placeholder, but a custom designed one is better).
*   **Screenshots**: At least one 1280x800px or 640x400px screenshot of your extension in action.
*   **Promotional Tile**: A 440x280px image to represent your extension in the store.

### C. Zip Your Extension
1.  Locate the `focus-manager` folder on your computer.
2.  Create a ZIP archive of the **contents** of this folder (select all files inside -> Right Click -> Compress).
    *   *Do not zip the folder itself, zip the files inside (manifest.json, popup.html, etc).*

## 2. Create a Developer Account

1.  Go to the [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/developer/dashboard).
2.  Sign in with the Google Account you want to use.
3.  Click **Register**.
4.  Pay the **$5.00 one-time registration fee**.

## 3. Upload Your Extension

1.  In the Developer Dashboard, click **+ New Item**.
2.  Upload the `.zip` file you created.
3.  **Important**: Once uploaded, copy the **Item ID** from the URL or dashboard.
    *   Go back to your Google Cloud Console and update your OAuth Credentials with this Item ID to ensure the login works.
    *   If you changed the ID, update `manifest.json` and re-zip/re-upload.

## 4. Fill Out the Store Listing

You will need to provide:
*   **Description**: Explain clearly what the extension does. Mention "Google Calendar integration" and "Distraction blocking".
*   **Category**: Choose "Productivity".
*   **Language**: Select "English".
*   **Graphic Assets**: Upload the icon, screenshots, and promo tile prepared in Step 1B.

## 5. Privacy Practices (Critical)

Since your extension uses `identity` (Login) and `calendar` (User Data), you must be very transparent.

1.  **Privacy Policy**: You **must** host a Privacy Policy URL.
    *   It can be a simple page (e.g., on GitHub Pages or a Google Doc) stating that you do not sell user data and only access the calendar to check for meeting times locally.
2.  **Permissions Justification**:
    *   **identity**: "Used to authenticate the user with Google Calendar."
    *   **storage**: "Used to save user preferences."
    *   **alarms**: "Used to poll for upcoming meetings."
    *   **declarativeNetRequest**: "Used to block distraction websites during focus sessions."

## 6. Submit for Review

1.  Click **Submit for Review**.
2.  The review process usually takes **24-48 hours**, but can take longer for extensions requesting broad permissions.
3.  Once approved, your extension will be live!

## 7. Post-Publishing

*   **Marketing**: Share the link with friends and on social media.
*   **Updates**: To update the extension, just increment the `version` in `manifest.json` (e.g., "1.1"), re-zip, and upload the new package in the dashboard.
